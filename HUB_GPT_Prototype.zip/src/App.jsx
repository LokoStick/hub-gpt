
import { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { gpts } from "./data/gpts";

function Navbar() {
  return (
    <nav className="w-full p-4 flex gap-4 border-b text-sm">
      <Link to="/">Inicio</Link>
      <Link to="/gpts">Todos los GPTs</Link>
      <Link to="/categorias">Categorías</Link>
      <Link to="/about">Acerca del Ecosistema</Link>
    </nav>
  );
}

function GPTCard({ gpt }) {
  return (
    <div className="border rounded-2xl p-4 shadow-sm hover:shadow-md transition">
      <h2 className="text-lg font-semibold">{gpt.nombre}</h2>
      <p className="text-xs text-gray-500">{gpt.rol}</p>
      <p className="mt-2 text-sm">{gpt.funciones}</p>
    </div>
  );
}

function GPTList() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 p-4">
      {gpts.map((gpt, idx) => (
        <GPTCard key={idx} gpt={gpt} />
      ))}
    </div>
  );
}

function Home() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-2">Bienvenido al HUB de GPTs Personalizados</h1>
      <p className="text-gray-600 text-sm max-w-xl">
        Explorá agentes IA estratégicos organizados por categorías, funciones y casos de uso. Este es tu centro de control para potenciar el ecosistema con inteligencia personalizada.
      </p>
    </div>
  );
}

function About() {
  return (
    <div className="p-4 max-w-xl">
      <h1 className="text-xl font-bold">Acerca del Ecosistema</h1>
      <p className="text-sm text-gray-600 mt-2">
        Este sitio reúne agentes IA diseñados para tareas estratégicas dentro de un ecosistema inteligente y modular. Cada uno tiene funciones clave que podés explorar y combinar.
      </p>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/gpts" element={<GPTList />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </Router>
  );
}
